#include "MEE_Texture.h"

int MEE::Texture::getWidth() const
{
    return width;
}

int MEE::Texture::getHeight() const
{
    return height;
}
