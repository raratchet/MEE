#include "MEE_GLFWHandler.h"

bool MEE::GLFWHandler::Init()
{
    return false;
}

void MEE::GLFWHandler::Stop()
{
}

void MEE::GLFWHandler::SwapBuffer()
{
}

void MEE::GLFWHandler::RefreshWindow()
{
}
