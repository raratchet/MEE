#pragma once

namespace MEE
{
	class FileSystem
	{

	};
}

