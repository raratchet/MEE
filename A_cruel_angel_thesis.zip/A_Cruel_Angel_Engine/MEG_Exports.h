#pragma once

#define MEG_EXPORT __declspec(dllexport)
#define MEG_IMPORT __declspec(dllimport)