#pragma once
#include "MEE_Application.h"
#include "MEE_Exports.h"

namespace MEE_GLOBAL
{
	 extern MEE_EXPORT MEE::Application* application;
}