#include "MEE_Global.h"

namespace MEE_GLOBAL
{
	MEE::Application* MEE_GLOBAL::application;
}
